#!/bin/bash
./manage.py makemigrations $1
