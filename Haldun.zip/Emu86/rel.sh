#!/bin/bash

cp ../mysite/static/Emu86/style.css .
git commit -a
git push origin master
