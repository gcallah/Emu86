# Emu86
This project will emulate an x86 assembler in Python, as a learning tool for students.
