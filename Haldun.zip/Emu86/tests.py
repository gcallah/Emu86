from django.test import TestCase


Class MoveTestCase(TestCase):

    def test_move():


