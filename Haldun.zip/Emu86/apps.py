from django.apps import AppConfig


class Emu86Config(AppConfig):
    name = 'Emu86'
