#!/bin/sh
./manage.py migrate
