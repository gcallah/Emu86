#!/bin/bash

git commit -a
git push origin dev
