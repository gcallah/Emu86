#!/bin/sh
./emu_container.sh /Users/gcallah/GitProjects/Emu86/
