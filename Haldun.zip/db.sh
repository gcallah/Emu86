#!/bin/bash
./stage.sh $1
./commit.sh
