#!/bin/sh
./emu_container.sh /Users/nconroy/Programming/emu86

